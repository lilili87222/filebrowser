(function () {
  window.onload = function () {
    var collapsed = document.getElementById('collapsed-button');
    var isDisplay = false;
    function setMenus() {
      var style = window.getComputedStyle(collapsed);
      var display;
      if (style.currentStyle) {
        display.currentStyle.display;
      } else {
        display = style.getPropertyValue('display');
      }
      if (display === 'none') {
        // 元素是隐藏的
        if (isDisplay) {
          isDisplay = false;
        }
      } else {
        // 元素是可见的
        if (!isDisplay) {
          isDisplay = true;
          var menu = document.getElementById('book-menus');
          var children = menu.children;
          Array.prototype.forEach.call(children, (i) => {
            var lists = i.classList;
            if (!Array.prototype.includes.call(lists, "active")) {
              lists.add("active")
            }
          });
        }
      }
    }
    setMenus();
    window.onresize = setMenus;
  };
})();
