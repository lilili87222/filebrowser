
# 一、hugo 前置元数据
指定一个网站页面或者文章的基本属性和元数据信息
```
+++
title = "Getting started"
description = ""
weight = 1
+++
```
在这个配置文件中，title 属性指定了该页面或文章的标题，description 属性则提供了一个简要的描述信息，weight 属性则用于定义该页面或文章在网站导航栏或者列表中的排序位置（数值越小，排名越高）。



# 二、用于生成网站的md文件存放位置

1. 在hugo中有特定的md存放位置，所有内容存放在content中,content里创建 _index.md 是用于网站的主页。
2. 应当创建目录分类文章，在新建的目录下新建 _index.md 用于这一章节的总结描述。
3. 生成的网站导航栏标题与文件名无关，是根据文章md里的title元数据指定的。


# 三、短码

1.  alert，警报短代码允许您通过警报样式框让信息脱颖而出。这可用于指示危险、警告、成功或信息。style有多个参数danger、warning、success、info

```
{{< alert style="warning" >}} [content] {{< /alert >}}
{{< alert style="danger" >}} [content] {{< /alert >}}
```

2. buttons，按钮短代码允许您向页面添加按钮。此按钮是一个 HTML 锚元素，因此可用于链接到另一个页面或网站
```
{{< button style="STYLE" link="https://yourwebsite.com" >}} [content] {{< /button >}}
```
3. childpages，短代码允许您显示当前页面的子页面列表。例如，本文档的入门页面有三个子页面：安装、配置和创建内容。将子页面短代码放在入门页面中将在该页面中创建这些子页面的列表。
```
{{< childpages >}}
```
4. 更多请参考[Ace documentation官网查看](https://docs.vantage-design.com/ace/shortcodes/)
