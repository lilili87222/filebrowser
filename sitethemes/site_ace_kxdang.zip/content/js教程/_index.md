+++
title = "Js Index"
description = "Js技术学习"
weight = 2

+++

# Hello World！！！


 <!-- {{- $currentNode := . }}
             

             {{ $category := $currentNode.Params.categories }}              
             {{ $pages := .Site.Home.Pages }}
             
             {{ $result := slice }}

             {{- if eq .Site.Params.ordersectionsby "title"}}
        
              

                {{- range $pages}}
                           
                  {{ $childPages := .Pages }}
                  {{ range $childPages }}
                    {{ $currentPage := . }}
                    
                    {{- if eq $currentPage.Params.categories $category}}
                      {{ $result = $result | append $currentPage }}
                    {{- end}}
                  {{ end }}               
                {{- end}}
              {{- range  $result.ByTitle}}
              {{$currentNode.Title}}     
                    {{- template "section-tree-nav" dict "sect" . "currentnode" $currentNode}}       
              {{- end}} 
             {{- else}}


        
              {{- range $pages}}           
                {{ $childPages := .Pages }}
                {{ range $childPages }}
                  {{ $currentPage := . }}
                  {{- if eq $currentPage.Params.categories $category}}
                    {{ $result = $result | append $currentPage }}
                  {{- end}}
                {{ end }}               
              {{- end}}
             {{- range  $result.ByWeight}}     
                  {{- template "section-tree-nav" dict "sect" . "currentnode" $currentNode}}       
             {{- end}} 
             {{- end}} -->
<!-- 
 {{- $rootSection:= . }}
              {{$result := slice}}
              {{ with . }}
              {{ if .Parent.IsHome }}
                <!-- 如果当前页面的父节点是根节点，则打印当前页面的 Title 属性 -->
                {{$rootSection = .  }}
              {{ else }}
                <!-- 否则继续递归查找 -->
                {{ with .Parent }}
                  {{ partial "menu.html" . }}
                {{ end }}
              {{ end }}
              {{ end }} -->
